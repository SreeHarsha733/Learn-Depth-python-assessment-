#even or odd 
x=int(input("enter any value"))
if x%2==0:
    print(x,"is even")
else :
    print(x,"is odd")    