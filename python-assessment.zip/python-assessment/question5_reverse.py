s=input("enter a string:")
print("The reverse of the string is:",s[::-1])